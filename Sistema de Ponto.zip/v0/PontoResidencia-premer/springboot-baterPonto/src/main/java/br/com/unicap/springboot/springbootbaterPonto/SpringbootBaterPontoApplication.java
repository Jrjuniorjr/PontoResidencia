package br.com.unicap.springboot.springbootbaterPonto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SpringbootBaterPontoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootBaterPontoApplication.class, args);
	}

	
}
