export class Relatorio {

    nome:string;
    matricula:string;
    somatorioH:number;
    entrada:number;
    saida:number;

}