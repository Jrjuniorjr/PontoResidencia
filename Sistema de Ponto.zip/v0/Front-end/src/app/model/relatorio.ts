// export class Relatorio {

//     nome:string;
//     matricula:string;
//     somatorioH:number;
//     entrada:number;
//     saida:number;

// }

export class Relatorio {

    constructor(
        public matricula:string,
        public nome:string,
        public entrada:number,
        public saida:number
    ){}

}